<?php
if(!defined('WP_UNINSTALL_PLUGIN'))exit;
global $wpdb;
foreach(['devices','messages','commands'] as $t)$wpdb->query('DROP TABLE IF EXISTS '.$wpdb->prefix.'msib_'.$t);
wp_clear_scheduled_hook('msib_cleanup');
