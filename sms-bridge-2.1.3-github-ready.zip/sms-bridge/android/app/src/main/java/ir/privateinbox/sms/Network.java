package ir.privateinbox.sms;
import java.net.*;import java.io.*;import org.json.*;
final class Network {
 static class HttpError extends IOException {final int code;HttpError(int c,String s){super(s);code=c;}}
 static JSONObject call(String site,String key,String path,JSONObject data)throws Exception{
  URL url=new URL(site+"/index.php?rest_route=/mobile-sms/v2/"+path);if(!url.getProtocol().equals("https"))throw new IOException("HTTPS required");
  HttpURLConnection c=(HttpURLConnection)url.openConnection();try{c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("X-MSI-Key",key);c.setRequestProperty("Accept","application/json");
   if(data!=null){c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");byte[] bytes=data.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}}
   int code=c.getResponseCode();if(code<200||code>=300){String message="HTTP "+code;try(InputStream err=c.getErrorStream()){if(err!=null){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[1024];int n;while((n=err.read(buf))!=-1&&out.size()<10000)out.write(buf,0,n);JSONObject e=new JSONObject(out.toString("UTF-8"));String detail=e.optString("message");if(detail.equals("unauthorized"))detail="کلید این حالت معتبر نیست؛ کلید گوشی سرور و کلید اتصال کلاینت متفاوت‌اند.";if(!detail.isEmpty())message+=" — "+detail;}}catch(Exception ignored){}throw new HttpError(code,message);}
   try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>2000000)throw new IOException("Response too large");}JSONObject j=new JSONObject(out.toString("UTF-8"));if(!j.optBoolean("ok"))throw new IOException("Invalid response");return j;}
  }finally{c.disconnect();}
 }
}
