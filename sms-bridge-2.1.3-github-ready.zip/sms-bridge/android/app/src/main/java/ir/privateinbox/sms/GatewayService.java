package ir.privateinbox.sms;
import android.app.*;import android.content.*;import android.os.*;import java.util.concurrent.*;
public class GatewayService extends Service {
 private ScheduledExecutorService executor;
 @Override public void onCreate(){super.onCreate();NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("sms-gateway","اتصال سرور پیامک",NotificationManager.IMPORTANCE_LOW));Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE);Notification n=new Notification.Builder(this,"sms-gateway").setContentTitle("سرور پیامک فعال است").setContentText("درخواست‌های کلاینت با سیم‌کارت این گوشی اجرا می‌شوند.").setSmallIcon(ir.privateinbox.sms.R.drawable.ic_inbox).setContentIntent(pi).setOngoing(true).build();startForeground(22,n);executor=Executors.newSingleThreadScheduledExecutor();executor.scheduleWithFixedDelay(()->{try{Gateway.tick(this);}catch(Exception e){Store.status(this,"اتصال سرور ناموفق: "+e.getMessage());}},0,30,TimeUnit.SECONDS);}
 @Override public int onStartCommand(Intent i,int flags,int id){return START_NOT_STICKY;}
 @Override public IBinder onBind(Intent i){return null;}
 @Override public void onDestroy(){if(executor!=null)executor.shutdownNow();super.onDestroy();}
}
