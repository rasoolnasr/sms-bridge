package ir.privateinbox.sms;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;

final class SmsPermissions {
 private static boolean granted(Context c,String p){return c.checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}
 static boolean ready(Context c){return granted(c,Manifest.permission.SEND_SMS)&&granted(c,Manifest.permission.RECEIVE_SMS);}
 static String summary(Context c){return "مجوز ارسال پیامک: "+(granted(c,Manifest.permission.SEND_SMS)?"فعال":"تأیید نشده")+"\nمجوز دریافت پیامک: "+(granted(c,Manifest.permission.RECEIVE_SMS)?"فعال":"تأیید نشده");}
 private static String operation(Context c,String permission){try{String op=AppOpsManager.permissionToOp(permission);if(op==null)return "نامشخص";AppOpsManager a=(AppOpsManager)c.getSystemService(Context.APP_OPS_SERVICE);int mode=Build.VERSION.SDK_INT>=29?a.unsafeCheckOpNoThrow(op,Process.myUid(),c.getPackageName()):a.checkOpNoThrow(op,Process.myUid(),c.getPackageName());switch(mode){case AppOpsManager.MODE_ALLOWED:return "مجاز";case AppOpsManager.MODE_IGNORED:return "مسدود / نادیده گرفته‌شده";case AppOpsManager.MODE_ERRORED:return "رد شده";case AppOpsManager.MODE_DEFAULT:return "پیش‌فرض سیستم";default:return "کد "+mode;}}catch(Exception e){return "قابل بررسی نیست";}}
 static String report(Activity a){String installer="نامشخص";try{String v=Build.VERSION.SDK_INT>=30?a.getPackageManager().getInstallSourceInfo(a.getPackageName()).getInstallingPackageName():a.getPackageManager().getInstallerPackageName(a.getPackageName());if(v!=null)installer=v;}catch(Exception ignored){}
 return "صندوق خصوصی پیامک — 2.1.3\n"+Build.MANUFACTURER+" "+Build.MODEL+"\nAndroid "+Build.VERSION.RELEASE+" / API "+Build.VERSION.SDK_INT+"\n"+summary(a)+"\nکنترل سیستم برای ارسال: "+operation(a,Manifest.permission.SEND_SMS)+"\nکنترل سیستم برای دریافت: "+operation(a,Manifest.permission.RECEIVE_SMS)+"\nنصب‌کننده: "+installer+"\n\nاگر تنظیمات گوشی پیامک را فعال نشان می‌دهد ولی یکی از مجوزهای بالا تأیید نشده است، این گزارش را برای بررسی بفرستید. این تفاوت ممکن است به محدودیت نصب مربوط باشد؛ علت قطعی هنوز مشخص نیست.\nکلاینت به مجوز پیامک نیاز ندارد. این گزارش شامل کلید اتصال یا متن پیام‌ها نیست.";
 }
 static void settings(Activity a){try{a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+a.getPackageName())));}catch(Exception e){new AlertDialog.Builder(a).setMessage("تنظیمات برنامه باز نشد.").setPositiveButton("بستن",null).show();}}
 static void show(Activity a){String report=report(a);new AlertDialog.Builder(a).setTitle("گزارش مجوزهای پیامک").setMessage(report).setPositiveButton("تنظیمات",(d,w)->settings(a)).setNeutralButton("کپی گزارش",(d,w)->{ClipboardManager c=(ClipboardManager)a.getSystemService(Context.CLIPBOARD_SERVICE);c.setPrimaryClip(ClipData.newPlainText("SMS permissions",report));}).setNegativeButton("بستن",null).show();}
}
