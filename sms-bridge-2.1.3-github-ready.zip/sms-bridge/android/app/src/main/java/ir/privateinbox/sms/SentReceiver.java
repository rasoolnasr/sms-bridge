package ir.privateinbox.sms;
import android.content.*;import org.json.*;
public class SentReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent intent){
  String journal=intent.getStringExtra("journal");if(journal==null||!journal.matches("job_[a-f0-9]{64}"))return;
  synchronized(Store.class){try{android.content.SharedPreferences p=Store.prefs(c);String value=p.getString(journal,null);if(value==null)return;JSONObject j=new JSONObject(value);int part=intent.getIntExtra("part",-1);if(part<0||part>=j.getInt("parts"))return;
   JSONArray done=j.getJSONArray("done");for(int k=0;k<done.length();k++)if(done.getInt(k)==part)return;done.put(part);if(getResultCode()!=android.app.Activity.RESULT_OK)j.put("failed",true);
   if(!p.edit().putString(journal,j.toString()).commit())throw new java.io.IOException();
   if(done.length()==j.getInt("parts")){Outbox.add(c,j.getString("site"),j.getString("key"),"server/result",new JSONObject().put("id",j.getLong("id")).put("claim",j.getString("claim")).put("status",j.getBoolean("failed")?"failed":"sent").put("detail",j.getBoolean("failed")?"one_or_more_parts_failed":"all_parts_sent_not_delivery_receipt"));Store.status(c,j.getBoolean("failed")?"ارسال یک یا چند قسمت ناموفق بود.":"پیامک توسط شبکهٔ گوشی ارسال شد.");}
  }catch(Exception e){Store.status(c,"خطا در ذخیره گزارش ارسال.");}}
 }
}
