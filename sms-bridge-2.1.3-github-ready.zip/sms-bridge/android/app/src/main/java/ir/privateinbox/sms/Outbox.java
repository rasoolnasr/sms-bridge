package ir.privateinbox.sms;
import android.content.Context;import org.json.*;import java.io.*;
final class Outbox {
 static synchronized void add(Context c,String site,String key,String route,JSONObject body)throws Exception{
  JSONObject envelope=new JSONObject().put("site",site).put("key",key).put("route",route).put("body",body);
  File f=new File(Store.queue(c),java.util.UUID.randomUUID()+".sms");try(OutputStream out=Store.encrypted(c,f).openFileOutput()){out.write(envelope.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));}UploadWorker.schedule(c);
 }
 static JSONObject read(Context c,File f)throws Exception{try(InputStream in=Store.encrypted(c,f).openFileInput();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[2048];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return new JSONObject(out.toString("UTF-8"));}}
 static synchronized void flush(Context c)throws Exception{File[] fs=Store.queue(c).listFiles((d,n)->n.endsWith(".sms"));if(fs==null)return;java.util.Arrays.sort(fs,java.util.Comparator.comparingLong(File::lastModified));for(File f:fs){if(!Store.prefs(c).getBoolean("enabled",false))return;JSONObject e=read(c,f);try{Network.call(e.getString("site"),e.getString("key"),e.getString("route"),e.getJSONObject("body"));}catch(Network.HttpError error){android.content.SharedPreferences current=Store.prefs(c);boolean old=!e.getString("site").equals(current.getString("site",""))||!e.getString("key").equals(current.getString("key",""));if(old&&(error.code==401||error.code==403)){File retired=new File(c.getNoBackupFilesDir(),"retired-queue");retired.mkdirs();if(!f.renameTo(new File(retired,f.getName())))throw new IOException("Old queue could not be isolated");Store.status(c,"یک پیام با کلید قدیمی در پوشهٔ امن جدا نگهداری شد؛ صف جدید ادامه پیدا می‌کند.");continue;}throw error;}if(!f.delete())throw new IOException("Delete failed");}}
}
