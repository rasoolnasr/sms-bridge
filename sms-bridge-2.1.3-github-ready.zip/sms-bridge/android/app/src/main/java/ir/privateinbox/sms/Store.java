package ir.privateinbox.sms;
import android.content.*;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKeys;
import java.util.UUID;
final class Store {
 static android.content.SharedPreferences prefs(Context c) throws Exception {
  return EncryptedSharedPreferences.create("connection",MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),c,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
 }
 static String device(Context c) throws Exception {
  android.content.SharedPreferences p=prefs(c); String id=p.getString("device","");
  if(id.isEmpty()){ id=UUID.randomUUID().toString(); p.edit().putString("device",id).commit(); } return id;
 }
 static java.io.File queue(Context c) { java.io.File d=new java.io.File(c.getNoBackupFilesDir(),"queue"); d.mkdirs(); return d; }
 static androidx.security.crypto.EncryptedFile encrypted(Context c,java.io.File f) throws Exception {
  return new androidx.security.crypto.EncryptedFile.Builder(f,c,MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),androidx.security.crypto.EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB).build();
 }
 static void status(Context c,String text) { c.getSharedPreferences("status",0).edit().putString("last",text).apply(); }
}
