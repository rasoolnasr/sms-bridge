package ir.privateinbox.sms;
import android.content.*;import android.provider.Telephony;import android.telephony.SmsMessage;import org.json.*;
public class SmsReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(i.getAction()))return;
  try{android.content.SharedPreferences p=Store.prefs(c);if(!p.getBoolean("enabled",false)||!p.getString("role","client").equals("server"))return;
   SmsMessage[] parts=Telephony.Sms.Intents.getMessagesFromIntent(i);if(parts.length==0)return;StringBuilder b=new StringBuilder();for(SmsMessage part:parts)b.append(part.getMessageBody());
   String sender=parts[0].getOriginatingAddress()==null?"unknown":parts[0].getOriginatingAddress();String fingerprint=Store.device(c)+"|"+sender+"|"+parts[0].getTimestampMillis()+"|"+b;
   String id=Gateway.hash(fingerprint);JSONObject body=new JSONObject().put("event_id",id).put("sender",sender).put("message",b.toString()).put("sent_at",java.time.Instant.ofEpochMilli(parts[0].getTimestampMillis()).toString());
   Outbox.add(c,p.getString("site",""),p.getString("key",""),"server/incoming",body);Store.status(c,"پیامک دریافتی در صف امن ذخیره شد.");
  }catch(Exception e){Store.status(c,"خطا در ذخیره پیامک؛ تنظیمات و حافظه گوشی را بررسی کنید.");}
 }
}
