package ir.privateinbox.sms;
import android.content.*;import android.telephony.SmsManager;import android.app.PendingIntent;import org.json.*;import java.util.*;
final class Gateway {
 static String hash(String s)throws Exception{byte[] digest=java.security.MessageDigest.getInstance("SHA-256").digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(byte x:digest)b.append(String.format(java.util.Locale.ROOT,"%02x",x&255));return b.toString();}
 static void tick(Context c)throws Exception{
  android.content.SharedPreferences p=Store.prefs(c);if(!p.getBoolean("enabled",false)||!p.getString("role","client").equals("server"))return;Exception uploadError=null;try{Outbox.flush(c);}catch(Exception e){uploadError=e;}
  if(c.checkSelfPermission(android.Manifest.permission.SEND_SMS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){Store.status(c,"مجوز ارسال SMS داده نشده است.");return;}
  String site=p.getString("site",""),key=p.getString("key","");JSONObject j=Network.call(site,key,"server/claim",new JSONObject());if(j.isNull("command")){Store.status(c,"سرور متصل است — "+java.time.Instant.now()+(uploadError==null?"":"؛ ارسال صف محلی ناموفق: "+uploadError.getMessage()));return;}
  JSONObject cmd=j.getJSONObject("command");String journal="job_"+hash(site+"|"+key+"|"+cmd.getLong("id"));
  synchronized(Store.class){if(p.contains(journal))return;
   SmsManager manager=SmsManager.getDefault();ArrayList<String> parts=manager.divideMessage(cmd.getString("message"));
   JSONObject record=new JSONObject().put("site",site).put("key",key).put("id",cmd.getLong("id")).put("claim",cmd.getString("claim")).put("parts",parts.size()).put("done",new JSONArray()).put("failed",false);
   // Persist intent-to-send BEFORE touching the SIM; a crash will not cause an automatic resend.
   if(!p.edit().putString(journal,record.toString()).commit())throw new java.io.IOException("Journal not saved");
   try{ArrayList<PendingIntent> sent=new ArrayList<>();for(int k=0;k<parts.size();k++){Intent callback=new Intent(c,SentReceiver.class).setAction("ir.privateinbox.sms.SENT").setData(android.net.Uri.parse("smsbridge://sent/"+journal+"/"+k)).putExtra("journal",journal).putExtra("part",k);sent.add(PendingIntent.getBroadcast(c,k,callback,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));}
    manager.sendMultipartTextMessage(cmd.getString("to"),null,parts,sent,null);
    Outbox.add(c,site,key,"server/result",new JSONObject().put("id",cmd.getLong("id")).put("claim",cmd.getString("claim")).put("status","submitted"));Store.status(c,"درخواست به سیستم SMS گوشی تحویل داده شد.");
   }catch(Exception e){Outbox.add(c,site,key,"server/result",new JSONObject().put("id",cmd.getLong("id")).put("claim",cmd.getString("claim")).put("status","unknown").put("detail","dispatch_exception_no_auto_retry"));Store.status(c,"نتیجه ارسال نامعلوم؛ برای جلوگیری از تکرار، خودکار دوباره ارسال نمی‌شود.");}
  }
 }
}
